# DDOS.SAMP-1.5

![Capture](https://user-images.githubusercontent.com/111334471/230767315-ab524c69-25fa-4610-8a4b-3ac134aebcb1.PNG)

# CMD 

git clone https://github.com/SAMPNUDOS/DDOS.SAMP-1.5 && cd DDOS.SAMP-1.5 && python3 SAMP-DDOS1.5.py

